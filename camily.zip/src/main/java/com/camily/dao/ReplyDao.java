package com.camily.dao;

import com.camily.dto.ReplyDto;

public interface ReplyDao {

	int getMaxBocode();

	int getMaxRpcode();

	int insertReplyWrite(ReplyDto ro);

	int deleteReply(int delRno);

}
