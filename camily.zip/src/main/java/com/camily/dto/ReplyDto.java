package com.camily.dto;

import lombok.Data;

@Data
public class ReplyDto {

	private int rpcode; 		// 덧글 코드 (PK)
	private String rpmid;		// 덧글 작성자 (FK)
	private String rpbocode;	// 덧글 작성한 글 코드 (FK)
	private String rpdate;			// 덧글 날짜
	private String rpcontents;	// 덧글 내용 (NOT NULL)
	
}
