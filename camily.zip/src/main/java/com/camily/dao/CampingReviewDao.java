package com.camily.dao;

public interface CampingReviewDao {

}
