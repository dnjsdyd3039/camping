package com.camily.dto;

public class CampingGoodsOrderDto {

	private String gocode;

	public String getGocode() {
		return gocode;
	}

	public void setGocode(String gocode) {
		this.gocode = gocode;
	}
	
}
