package com.camily.service;

import org.springframework.stereotype.Service;

@Service
public class CampingReviewService {

}
