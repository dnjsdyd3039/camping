package com.camily.dto;

import lombok.Data;

@Data
public class CampingDto {

	private String cacode;
	private String caname;
	private String calatitude;
	private String calongitude;
	private String catype;
	private String cacontents;
	private String calinecontents;
	private String caprice;
	private String cainfo;
	private String caimage;
	
	private String crprice;
	
}
