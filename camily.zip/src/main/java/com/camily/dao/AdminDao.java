package com.camily.dao;


public interface AdminDao {

}
